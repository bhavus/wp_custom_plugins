<?php
/**
 * Plugin Name: Events (Post Category Tag) Plugin
 * Description: This plugin will add a Custom Post Type for Events
 * Plugin URI: https://xyz.com
 * Author: Shailesh Parmar
 * Version: 1.0
**/

//* Don't access this file directly
defined( 'ABSPATH' ) or die();

/*------------------------------------*\
	Create Custom Post Types
\*------------------------------------*/
add_action('init', 'medic_event_post_type');
function medic_event_post_type() {

    // Events Custom Post
    $event_labels = array(
            'labels' => array(
            'name' => __('Events', 'vicodemedia'),
            'singular_name' => __('Event', 'vicodemedia'),
            // 'featured_image' =>  __('Event Image', 'vicodemedia'),
            // 'set_featured_image' => 'Set Event Image',
            // 'remove_featured_image' => 'Remove Event Image',
            // 'use_featured_image' => 'Use as Event Image',
            'add_new' => __('Add New', 'vicodemedia'),
            'add_new_item' => __('Add New Event', 'vicodemedia'),
            'edit_item' => __('Edit Event', 'vicodemedia'),
            'new_item' => __('New Event', 'vicodemedia'),
            'view_item' => __('View Event', 'vicodemedia'),
            'view_items' => __('View Events', 'vicodemedia'),
            'search_items' => __('Search Events', 'vicodemedia'),
            'not_found' => __('No events found.', 'vicodemedia'),
            'not_found_in_trash' => __('No events found in trash.', 'vicodemedia'),
            'all_items' => __('All Events', 'vicodemedia'),
            'archives' => __('Event Archives', 'vicodemedia'),
            'insert_into_item' => __('Insert into Event', 'vicodemedia'),
            'uploaded_to_this_item' => __('Uploaded to this Event', 'vicodemedia'),
            'filter_items_list' => __('Filter Events list', 'vicodemedia'),
            'items_list_navigation' => __('Events list navigation', 'vicodemedia'),
            'items_list' => __('Events list', 'vicodemedia'),
            'item_published' => __('Event published.', 'vicodemedia'),
            'item_published_privately' => __('Event published privately.', 'vicodemedia'),
            'item_reverted_to_draft' => __('Event reverted to draft.', 'vicodemedia'),
            'item_scheduled' => __('Event scheduled.', 'vicodemedia'),
            'item_updated' => __('Event updated.', 'vicodemedia')
           )
        );

    $event_args = array(
        'public' => true,
        'labels' => $event_labels,
        'label' => __('Events', 'lawenforce'),
        'has_archive'   => true,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var'    => true,
        'rewrite'      => array('slug' => 'event'),
        'show_in_rest' => true,
        'supports' => array('title','editor','excerpt', 'thumbnail', 'gallery'),
        'can_export' => true
    );
    register_post_type('event', $event_args);

     // Add new taxonomy, make it hierarchical (like categories)
    $cat_labels = array(
        'name' => _x('Events Categories', 'taxonomy general name', 'textdomain'),
        'singular_name' => _x('event Category', 'taxonomy singular name', 'textdomain'),
        'search_items' => __('Search Categories', 'textdomain'),
        'all_items' => __('All Categories', 'textdomain'),
        'parent_item' => __('Parent Category', 'textdomain'),
        'parent_item_colon' => __('Parent Category:', 'textdomain'),
        'edit_item' => __('Edit Category', 'textdomain'),
        'update_item' => __('Update Category', 'textdomain'),
        'add_new_item' => __('Add New Category', 'textdomain'),
        'new_item_name' => __('New Category Name', 'textdomain'),
        'menu_name' => __('Events Category', 'textdomain'),
    );

    $cat_args = array(
        'hierarchical' => true,
        'labels' => $cat_labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'event_category'),
    );
    register_taxonomy('event_category', array('event'), $cat_args);

    //You can register a custom taxonomy for your event post type to serve as custom event tags. 
   
        $tag_labels = array(
            'name' => 'Event Tags',
            'singular_name' => 'Event Tag',
            'search_items' => 'Search Event Tags',
            'all_items' => 'All Event Tags',
            'edit_item' => 'Edit Event Tag',
            'update_item' => 'Update Event Tag',
            'add_new_item' => 'Add New Event Tag',
            'new_item_name' => 'New Event Tag Name',
            'menu_name' => 'Event Tags',
        );

        $tag_args = array(
            'hierarchical' => false, // Set to true if you want hierarchical tags like categories
            'labels' => $tag_labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'event-tag'), // Customize the slug
        );
        register_taxonomy('event_tag', 'event', $tag_args);
 
}

/*-------------------------------------------------------------
  Rename Featured image to Event Image
--------------------------------------------------------------*/
function medic_rename_featured_image_label($args, $post_type) {
    if ($post_type === 'event') { // Replace 'post' with the post type where you want to rename the label
        $args['labels']['featured_image'] = 'Event Image';
        $args['labels']['set_featured_image'] = 'Set Event Image';
        $args['labels']['remove_featured_image'] = 'Remove Event Image';
        $args['labels']['use_featured_image'] = 'Use as Event Image';
    }
    return $args;
}
add_filter('register_post_type_args', 'medic_rename_featured_image_label', 10, 2);

/*-------------------------------------------------------------
  Add custom column to ( Event Thumbnail and Event Date ) event post type
--------------------------------------------------------------*/
function medic_add_event_thumbnail_column($column) {
    $column['event_thumbnail'] = 'Event Thumbnail';
    $column['event_date'] = 'Event Date';
    return $column;
}
add_filter('manage_edit-event_columns', 'medic_add_event_thumbnail_column');

// Display event thumbnail in custom column
function medic_display_event_thumbnail_column($column, $post_id) {
  
 switch($column){
    case 'event_thumbnail':
        $e_thumbnail = get_the_post_thumbnail($post_id, 'thumbnail'); 
        echo $e_thumbnail ? $e_thumbnail : 'No Image';
        break;
    case 'event_date':
        $e_date = get_post_meta($post_id, 'event_date', true);
        echo $e_date ? $e_date : 'No Date';
        break;
  }
}
add_action('manage_event_posts_custom_column', 'medic_display_event_thumbnail_column', 10, 2);
/*-------------------------------------------------------------
  Make the (column name) Column Sortable to events post type
--------------------------------------------------------------*/
function medic_sortable_column($column) {
    $column['event_date'] = 'event_date';
    return $column;
}
add_filter('manage_edit-event_sortable_columns', 'medic_sortable_column');

/*-------------------------------------------------------------
  (step-1) add event date meta field to events post type
--------------------------------------------------------------*/
function medic_add_post_meta_boxes() {
    add_meta_box(
        "post_metadata_events_post", // div id containing rendered fields
        "Event Date", // section heading displayed as text
        "medic_event_date_callback", // callback function to render fields
        "event", // name of post type on which to render fields
        "side", // location on the screen
        "low" // placement priority
    );
    add_meta_box('author-id', 'Event Author', 'medic_my_display_callback_author', 'event','side','low');
}
add_action( "admin_init", "medic_add_post_meta_boxes" );

/*-------------------------------------------------------------
  (step-2) above callback function Design html
--------------------------------------------------------------*/
function medic_event_date_callback($post)
{
    global $post;
    $event_date = get_post_meta($post->ID, 'event_date', true);
    ?>
    <label for="event_date">Event Date:</label>
    <input type="date" id="event_date" name="event_date" value="<?php echo esc_attr($event_date); ?>">
    <?php
}

/*-------------------------------------------------------------
  (Step-3) Save post publish then event metabox saved event date
--------------------------------------------------------------*/
function medic_save_event_date($post_id) {
    if (array_key_exists('event_date', $_POST)) {
        update_post_meta($post_id, 'event_date', sanitize_text_field($_POST['event_date']));
    }
}
add_action('save_post', 'medic_save_event_date');

/*-------------------------------------------------------------
  Assign custom template to single event post type
--------------------------------------------------------------*/
function medic_load_event_template( $template ) {
    global $post;
    if ( 'event' === $post->post_type && locate_template( array( 'single-event.php' ) ) !== $template ) {
        return plugin_dir_path( __FILE__ ) . 'single-event.php';
    }

    return $template;
}
add_filter( 'single_template', 'medic_load_event_template' );


/*-------------------------------------------------------------
  Event Post list display by Shortcode
--------------------------------------------------------------*/
add_shortcode('events_list', 'medic_events_list');
function medic_events_list(){
    global $post;
    $args = array(
        'post_type'=>'event', 
        'post_status'=>'publish', 
        'posts_per_page'=>10, 
        'orderby'=>'meta_value',
        'meta_key' => 'event_date',
        'order'=>'ASC'
    );
    $query = new WP_Query($args);

    // ob_start();

    $content = '<ul>';
    if($query->have_posts()):
        while($query->have_posts()): $query->the_post();
            // trash event if old
            $exp_date = get_post_meta(get_the_ID(), 'event_date', true);
            // set the correct timezone
            date_default_timezone_set('America/New_York');
            $today = new DateTime();
            if($exp_date < $today->format('Y-m-d h:i:sa')){
                // Update post
                $current_post = get_post( get_the_ID(), 'ARRAY_A' );
                $current_post['post_status'] = 'trash';
                wp_update_post($current_post);
            }
            // display event
            $content .= '<li><a href="'.get_the_permalink().'">'. get_the_title() .'</a> - '.date_format(date_create(get_post_meta($post->ID, 'event_date', true)), 'jS F').'</li>'; 
        endwhile;
    else: 
        _e('Sorry, nothing to display.', 'vicodemedia');
    endif;
    $content .= '</ul>';

  // return ob_get_clean();
    return $content;
}

/*-------------------------------------------------------------
 ( medic_filter_by_category ) to event post type
--------------------------------------------------------------*/
add_action('restrict_manage_posts','medic_category_filter');
    function medic_category_filter(){
        global $typenow;
        $show_taxonomy = 'event_category';
        $selected_event_category_id = isset($_GET[$show_taxonomy]) ? intval($_GET[$show_taxonomy]) : "";

        if($typenow == 'event'){
            $args = array(
                'show_option_all' => 'Show all',
                'taxonomy' => $show_taxonomy,
                'show_count' => true,
                'name'=> $show_taxonomy,
                'selected' => $selected_event_category_id,
            );
            wp_dropdown_categories($args);
        }
    }


add_filter('parse_query', 'medic_filter_by_category');

function medic_filter_by_category($query){
    global $typenow;
    global $pagenow;
    $post_type = 'event';
    $taxonomy = 'event_category';
    $query_var = &$query->query_vars;

    if ($typenow == $post_type && $pagenow == 'edit.php' && isset($query_var[$taxonomy]) && is_numeric($query_var[$taxonomy])) {
        $term_details = get_term_by("id", $query_var[$taxonomy], $taxonomy);

        // Check if $term_details is a valid term object
        if ($term_details && !is_wp_error($term_details)) {
            $query_var[$taxonomy] = $term_details->slug;
        }
    }
}
/*-------------------------------------------------------------
 ( medic_filter_by_Author ) to event post type
--------------------------------------------------------------*/
     function medic_my_display_callback_author($post){
        ?>
        <select name="author_select" id="<?php echo $post->ID; ?>">
            <option value="">Select Author</option> <!-- Add a default option -->
            <?php 
            $author_select = get_post_meta($post->ID, 'author_select', true);
            $authors = get_users(array('role' => 'author'));

            foreach ($authors as $author) {
                $select = '';
                if ($author_select == $author->ID) {
                    $select = 'selected="selected"';
                }
                ?>
                <option value="<?php echo $author->ID; ?>" <?php echo $select; ?>><?php echo $author->display_name; ?></option>
                <?php
            }
            ?>
        </select>
        <?php
    }


    add_action('save_post','medic_author_save_data',10,2);
    function medic_author_save_data($post_id,$post){
        $author = isset($_POST['author']) ? $_POST['author'] : ''; 
        update_post_meta($post_id,'author_select', $author);
    }

    //start filter author
    add_action('restrict_manage_posts', 'medic_author_filter');
    function medic_author_filter(){
        global $typenow;
        if ($typenow == 'event') {
            // Check if the 'author_filter' parameter exists in the URL
            $author_id = isset($_GET['author_filter']) ? $_GET['author_filter'] : '';
            $args = array(
                'role'             => 'author',
                'show_option_none' => 'Select Author',
                'name'             => 'author_filter',
                'id'               => 'all_author_fileter',   // integer
                'selected'         => $author_id,
            );
            wp_dropdown_users($args);
        }
    }

    add_filter( 'parse_query','medic_filter_by_author' );
    function medic_filter_by_author($query){
        global $typenow;
        global $pagenow;
        $author_id= isset($_GET['author_filter']) ? $_GET['author_filter'] : '';
        if($typenow == 'event' && $pagenow == 'edit.php' && !empty($author_id)){
            $query->query_vars["meta_key"]   = 'author_select';
            $query->query_vars["meta_value"] = $author_id;

        }
    }